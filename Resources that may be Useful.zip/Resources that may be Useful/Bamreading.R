#install dplyr, stringr, Genomic Alignments
library(dplyr)
library(stringr)
library(GenomicAlignments)

#install if necessary
source("http://bioconductor.org/biocLite.R")
biocLite("Rsamtools")

#load library
library(Rsamtools)

#gal <- readGAlignments("S1_R1_001.bam")
#length(gal)
#strand(gal)
#table(strand(gal))

#read in entire BAM file
bam11 <- scanBam("possorted_genome_bam.bam")

#names of the BAM fields
names(bam11[[1]])
# [1] "qname" "flag" "rname" "strand" "pos" "qwidth" "mapq" "cigar"
# [9] "mrnm" "mpos" "isize" "seq" "qual"

#distribution of BAM flags
table(bam11[[1]]$flag)

# 0 4 16 
#1472261 775200 1652949

#function for collapsing the list of lists into a single list
#as per the Rsamtools vignette
.unlist <- function (x){
  ## do.call(c, ...) coerces factor to integer, which is undesired
  x1 <- x[[1L]]
  if (is.factor(x1)){
    structure(unlist(x), class = "factor", levels = levels(x1))
  } else {
    do.call(c, x)
  }
}

#store names of BAM fields
bam_field <- names(bam11[[1]])

#go through each BAM field and unlist
list <- lapply(bam_field, function(y) .unlist(lapply(bam11, "[[", y)))

#store as data frame
bam11_df <- do.call("DataFrame", list)
names(bam11_df) <- bam_field

dim(bam11_df)
#[1] 3900410 13
library(data.table)
#Convert dataframe to datatable
bam11dt <- as.data.table(bam11_df, keep.rownames=FALSE)
#Extract flag, mapq, sequence of strand, cigar quality to do QC of reads
flagseq11 <- data.table(bam11dt$flag,bam11dt$mapq,bam11dt$seq,bam11dt$cigar)
#Initialise colheaders
colnames(flagseq11) <- c("flag","mapquality","sequence","cigar")
#Filter those columns with flag more than 200
flagseqfiltered11 <- flagseq11 %>% filter(flag > 200)
#Order the columns by flag to get pairs
flagseqfiltered11 <- flagseqfiltered11[order(flagseqfiltered11$flag),]


#read tsv (tab0-separated values) for further information
tsv1 <- read.table(file = 'features.tsv', sep = '\t', header = TRUE)
