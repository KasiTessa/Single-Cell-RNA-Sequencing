#install developer package if needed
install.packages("devtools")

devtools::install_github("satijalab/seurat", ref = "develop")
library(Seurat)

a <- read.csv("haveinfo.csv",header = TRUE)

a <- read.table("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/RH_LCL_hg19/genes.tsv",
                     
                     h=TRUE, sep="\t", stringsAsFactors=FALSE)

RH_3_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/RH_LCL_hg19/")
RH_3_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/RH_3_28_hg19/")
RH_5_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/RH_LCL_hg19/")
RH_5_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/RH_3_28_hg19/")

DM_3_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/DM_LCL_hg19/")
DM_3_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/DM_3_28_hg19/")
DM_5_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/DM_LCL_hg19/")
DM_5_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/DM_3_28_hg19/")

WYO_3_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/WYO_LCL_hg19/")
WYO_3_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/WYO_3_28_hg19/")
WYO_5_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/WYO_LCL_hg19/")
WYO_5_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/WYO_3_28_hg19/")

ZHB_3_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/ZHB_LCL_hg19/")
ZHB_3_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/ZHB_3_28_hg19/")
ZHB_5_LCL_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/ZHB_LCL_hg19/")
ZHB_5_ATC_data <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/ZHB_3_28_hg19/")

#Initialise Seurat Object
All_Combined <- CreateSeuratObject(raw.data = DM_3_ATC_data, min.cells = 3, min.genes = 200, project = "All_Combined")
All_Combined1 <- CreateSeuratObject(raw.data = DM_3_ATC_data, min.cells = 3, min.genes = 200, project = "All_Combined")
All_Combined2 <- CreateSeuratObject(raw.data = DM_5_ATC_data, min.cells = 3, min.genes = 200, project = "All_Combined")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = DM_3_LCL_data, add.cell.id = "DM_3_LCL")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = RH_3_LCL_data, add.cell.id = "RH_3_LCL")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = RH_3_ATC_data, add.cell.id = "RH_3_ATC")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = WYO_3_LCL_data, add.cell.id = "WYO_3_LCL")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = WYO_3_ATC_data, add.cell.id = "WYO_3_ATC")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = ZHB_3_LCL_data, add.cell.id = "ZHB_3_LCL")
All_Combined1 <- AddSamples(object = All_Combined1, new.data = ZHB_3_ATC_data, add.cell.id = "ZHB_3_ATC")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = DM_5_LCL_data, add.cell.id = "DM_5_LCL")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = RH_5_ATC_data, add.cell.id = "RH_5_ATC")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = RH_5_LCL_data, add.cell.id = "RH_5_LCL")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = WYO_5_ATC_data, add.cell.id = "WYO_5_ATC")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = WYO_5_LCL_data, add.cell.id = "WYO_5_LCL")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = ZHB_5_LCL_data, add.cell.id = "ZHB_5_LCL")
All_Combined2 <- AddSamples(object = All_Combined2, new.data = ZHB_5_ATC_data, add.cell.id = "ZHB_5_ATC")
#Do this 15 times
All_Combined <- AddSamples(object = All_Combined, new.data = DM_3_LCL_data, add.cell.id = "DM_3_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = RH_3_LCL_data, add.cell.id = "RH_3_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = RH_3_ATC_data, add.cell.id = "RH_3_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = WYO_3_LCL_data, add.cell.id = "WYO_3_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = WYO_3_ATC_data, add.cell.id = "WYO_3_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = ZHB_3_LCL_data, add.cell.id = "ZHB_3_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = ZHB_3_ATC_data, add.cell.id = "ZHB_3_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = DM_5_ATC_data, add.cell.id = "DM_5_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = DM_5_LCL_data, add.cell.id = "DM_5_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = RH_5_ATC_data, add.cell.id = "RH_5_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = RH_5_LCL_data, add.cell.id = "RH_5_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = WYO_5_ATC_data, add.cell.id = "WYO_5_ATC")
All_Combined <- AddSamples(object = All_Combined, new.data = WYO_5_LCL_data, add.cell.id = "WYO_5_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = ZHB_5_LCL_data, add.cell.id = "ZHB_5_LCL")
All_Combined <- AddSamples(object = All_Combined, new.data = ZHB_5_ATC_data, add.cell.id = "ZHB_5_ATC")
#Find the size of seurat object
dense.size <- object.size(x = as.matrix(x = All_Combined))
#Find the highly mitochondrial genes
mito.genes <- grep(pattern = "^MT-", x = rownames(x = All_Combined@data), value = TRUE)
#Get percentage of mitochondrial genes, add to metadata and plot the features of genes, mitochondrialgenes
percent.mito <- Matrix::colSums(All_Combined@raw.data[mito.genes, ])/Matrix::colSums(All_Combined@raw.data)

All_Combined <- AddMetaData(object = All_Combined, metadata = percent.mito, col.name = "percent.mito")
png("VlnPlot1.png")
VlnPlot(object = All_Combined, features.plot = c("nGene", "nUMI", "percent.mito"), nCol = 3)
dev.off()
#create png and save it
png("Geneplots1.png")
#Plot the Ngene, mitochondrial gene to see how much is represented . Ngene should be represented mainly
par(mfrow = c(1,2))
GenePlot(object = All_Combined, gene1 = "nUMI", gene2 = "percent.mito")
GenePlot(object = All_Combined, gene1 = "nUMI", gene2 = "nGene")
dev.off()
#Plot the hist of mitochondrial genes, ngenes
png("Hist3.png")
hist(All_Combined2@meta.data$percent.mito)
hist(All_Combined2@meta.data$nGene)
#barplot(All_Combined@meta.data$nGene, c(2,5), main = "nGene", xlab = "Genes", ylab = "Count")
dev.off()
#Do normalisation and filter those mitochondrial and ngenes and find variable genes
All_Combined <- FilterCells(object = All_Combined, subset.names = c("nGene", "percent.mito"), low.thresholds = c(1000, -Inf), high.thresholds = c(4000, 0.1))
All_Combined <- NormalizeData(object = All_Combined, normalization.method = "LogNormalize", scale.factor = 10000)
png("Expression-dispersion1.png")
par(mfrow = c(1,1))
All_Combined <- FindVariableGenes(object = All_Combined, mean.function = ExpMean, dispersion.function = LogVMR, x.low.cutoff = 0.0125, x.high.cutoff = 3, y.cutoff = 0.5)
dev.off()
length(x = All_Combined@var.genes)

#Stopped here

a <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/Key intersection of Variable genes/intersection.csv") 
haveinfo <- all_combined@hvg.info
a1 <- row.names(haveinfo)
a1 <- as.data.table(a1)
haveinfo <- merge(haveinfo,a1,by="row.names",all.x=TRUE)
haveinfo$a1 <- NULL
set <- subset(haveinfo,Row.names %in% a$Variable.genes)
DoHeatmap(object = all_combined, genes.use = set$Row.names, slim.col.label = TRUE, remove.key = TRUE)
#Scale data and remove those mitochondrial genes and run PCA to get more highly variable genes
All_Combined <- ScaleData(object = All_Combined, vars.to.regress = c("nUMI"))
all_combined <- ScaleData(object = all_combined, vars.to.regress = c("nUMI"))
#All_Combined <- ScaleData(object = All_Combined)
All_Combined <- RunPCA(object = All_Combined, pc.genes = All_Combined@var.genes, do.print = TRUE, pcs.print = 1:5, genes.print = 5)
