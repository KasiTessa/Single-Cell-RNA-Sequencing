a <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/DM_3_28/commongenes1.csv")
b <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/DM_LCL/commongenes2.csv")
h <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/ZHB_LCL/commongenes8.csv")
g <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/ZHB_3_28/commongenes7.csv")
f <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/WYO_LCL/commongenes6.csv")
d <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/RH_LCL/commongenes4.csv")
e <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/WYO_3_28/commongenes5.csv")
c <- read.csv("C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/Results of 3' and 5' kits/RH_3_28/commongenes3.csv")


#Appear LCL
intersection2 <- intersect(b$common,d$common)
intersection2 <- as.data.frame(intersection2)
intersection2 <- intersect(intersection2$intersection2, f$common)
intersection2 <- as.data.frame(intersection2)
intersection2 <- intersect(intersection2$intersection2, h$common)
intersection2 <- as.data.frame(intersection2)

#Appear3_28
intersection1 <- intersect(a$common,c$common)
intersection1 <- as.data.frame(intersection1)
intersection1 <- intersect(intersection1$intersection1, e$common)
intersection1 <- as.data.frame(intersection1)
intersection1 <- intersect(intersection1$intersection1, g$common)
intersection1 <- as.data.frame(intersection1)

#Appear 8 time
intersection <- intersect(a$common,b$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, c$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, d$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, e$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, f$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, g$common)
intersection <- as.data.frame(intersection)
intersection <- intersect(intersection$intersection, h$common)
intersection <- as.data.frame(intersection)



#Appear one time
union1 <- union(a$common,b$common1)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common1)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union3 <- union(union2$union2,d$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union2$union2,d$common1)), ]
union3 <- as.data.frame(union3)
union4 <- union(union3$union3,e$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union3$union3,e$common)), ]
union4 <- as.data.frame(union4)
union5 <- union(union4$union4,f$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union4$union4,f$common)), ]
union5 <- as.data.frame(union5)
union6 <- union(union5$union5,g$common)
union6 <- as.data.frame(union6)
union6 <- union6[!(union6$union6 %in% intersect(union5$union5,g$common)), ]
union6 <- as.data.frame(union6)
union7 <- union(union6$union6,h$common)
union7 <- as.data.frame(union7)
union7 <- union7[!(union7$union7 %in% intersect(union6$union6,h$common)), ]
union7 <- as.data.frame(union7)
write.csv(union7,file = "appear1time.csv")

#Appear seven times
#First permutation with intersections. Do this 28 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,c$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,d$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,e$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,f$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,g$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,h$common)
union1 <- as.data.frame(union1)

union2 <- union(g$common,h$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(h$common,g$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,a$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,f$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,e$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,c$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,b$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,d$common)
union2 <- as.data.frame(union2)

union1 <- union(union1$union1,union2$union2)
union1 <- as.data.frame(union1)

write.csv(union1,file = "appear7time.csv")

#Appear 6 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,d$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,e$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,f$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,g$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,h$common)
union2 <- as.data.frame(union2)

union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union3 <- union(union1$union1,h$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union1$union1,d$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,c$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,e$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,f$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,g$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,h$common)
union3 <- as.data.frame(union3)

union2 <- union(union2$union2,union3$union3)
union2 <- as.data.frame(union2)

write.csv(union2,file = "appear6time.csv")

#Appear 5 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,d$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,d$common)), ]
union5 <- as.data.frame(union5)
union5 <- intersect(union5$union5,e$common)
union5 <- as.data.frame(union5)
union5 <- intersect(union5$union5,f$common)
union5 <- as.data.frame(union5)
union5 <- intersect(union5$union5,g$common)
union5 <- as.data.frame(union5)
union5 <- intersect(union5$union5,h$common)
union5 <- as.data.frame(union5)

union1 <- union(e$common,f$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(e$common,f$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,h$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,h$common)), ]
union2 <- as.data.frame(union2)
union3 <- union(union2$union2,g$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union2$union2,g$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,a$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,b$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,d$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,c$common)
union3 <- as.data.frame(union3)

union5 <- union(union5$union5,union3$union3)
union5 <- as.data.frame(union5)

write.csv(union5,file = "appear5time.csv")

#Appear4 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,d$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,d$common)), ]
union5 <- as.data.frame(union5)
union4 <- union(union5$union5,e$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union5$union5,e$common)), ]
union4 <- as.data.frame(union4)
union4 <- intersect(union4$union4,f$common)
union4 <- as.data.frame(union4)
union4 <- intersect(union4$union4,g$common)
union4 <- as.data.frame(union4)
union4 <- intersect(union4$union4,h$common)
union4 <- as.data.frame(union4)

union1 <- union(h$common,d$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(h$common,d$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,g$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,g$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,f$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,f$common)), ]
union5 <- as.data.frame(union5)
union3 <- union(union5$union5,e$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union3$union3,e$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,a$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,b$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,c$common)
union3 <- as.data.frame(union3)

union4 <- union(union4$union4,union3$union3)
union4 <- as.data.frame(union4)

write.csv(union4,file = "appear4time.csv")

#Appear3 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,d$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,d$common)), ]
union5 <- as.data.frame(union5)
union4 <- union(union5$union5,e$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union5$union5,e$common)), ]
union4 <- as.data.frame(union4)
union6 <- union(union4$union4,f$common)
union6 <- as.data.frame(union6)
union6 <- union6[!(union6$union6 %in% intersect(union4$union4,f$common)), ]
union6 <- as.data.frame(union6)
union6 <- intersect(union6$union6,g$common)
union6 <- as.data.frame(union6)
union6 <- intersect(union6$union6,h$common)
union6 <- as.data.frame(union6)

union1 <- union(c$common,d$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(c$common,d$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,e$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,e$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,f$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,f$common)), ]
union5 <- as.data.frame(union5)
union4 <- union(union5$union5,h$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union5$union5,h$common)), ]
union4 <- as.data.frame(union4)
union3 <- union(union4$union4,g$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union4$union4,g$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,a$common)
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,b$common)
union3 <- as.data.frame(union3)

union6 <- union(union6$union6,union3$union3)
union6 <- as.data.frame(union6)

write.csv(union6,file = "appear3time.csv")

#Appear2 times
union1 <- union(a$common,b$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,b$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,c$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,d$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,d$common)), ]
union5 <- as.data.frame(union5)
union4 <- union(union5$union5,e$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union5$union5,e$common)), ]
union4 <- as.data.frame(union4)
union6 <- union(union4$union4,f$common)
union6 <- as.data.frame(union6)
union6 <- union6[!(union6$union6 %in% intersect(union4$union4,f$common)), ]
union6 <- as.data.frame(union6)
union7 <- union(union6$union6,g$common)
union7 <- as.data.frame(union7)
union7 <- union7[!(union7$union7 %in% intersect(union6$union6,g$common)), ]
union7 <- as.data.frame(union7)
union7 <- intersect(union7$union7,h$common)
union7 <- as.data.frame(union7)

union1 <- union(b$common,c$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(b$common,c$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,d$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,d$common)), ]
union2 <- as.data.frame(union2)
union5 <- union(union2$union2,e$common)
union5 <- as.data.frame(union5)
union5 <- union5[!(union5$union5 %in% intersect(union2$union2,e$common)), ]
union5 <- as.data.frame(union5)
union4 <- union(union5$union5,f$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union5$union5,f$common)), ]
union4 <- as.data.frame(union4)
union6 <- union(union4$union4,g$common)
union6 <- as.data.frame(union6)
union6 <- union6[!(union6$union6 %in% intersect(union4$union4,g$common)), ]
union6 <- as.data.frame(union6)
union3 <- union(union6$union6,h$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union6$union6,h$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,a$common)
union3 <- as.data.frame(union3)

union7 <- union(union7$union7,union3$union3)
union7 <- as.data.frame(union7)

write.csv(union7,file = "appear2time.csv")

#Appear 1 time 3_28
union2 <- union(a$common,c$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(a$common,c$common)), ]
union2 <- as.data.frame(union2)
union3 <- union(union2$union2,e$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union2$union2,e$common)), ]
union3 <- as.data.frame(union3)
union4 <- union(union3$union3,g$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union3$union3,g$common)), ]
union4 <- as.data.frame(union4)

write.csv(union4,file = "appear3_281time.csv")

#Appear 1 time LCL
union2 <- union(b$common,d$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(b$common,d$common)), ]
union2 <- as.data.frame(union2)
union3 <- union(union2$union2,f$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union2$union2,f$common)), ]
union3 <- as.data.frame(union3)
union4 <- union(union3$union3,h$common)
union4 <- as.data.frame(union4)
union4 <- union4[!(union4$union4 %in% intersect(union3$union3,h$common)), ]
union4 <- as.data.frame(union4)

write.csv(union4,file = "appearLCL1time.csv")

#Appear 3 time LCL
union1 <- union(b$common,d$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(b$common,d$common)), ]
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,f$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,h$common)
union1 <- as.data.frame(union1)

union2 <- union(h$common,f$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(h$common,f$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,d$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,b$common)
union2 <- as.data.frame(union2)

union1 <- union(union1$union1,union2$union2)
union1 <- as.data.frame(union1)

write.csv(union1,file = "appearLCL3time.csv")

#Appear 3 time 3_28
union1 <- union(a$common,c$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,c$common)), ]
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,e$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,g$common)
union1 <- as.data.frame(union1)

union2 <- union(g$common,e$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(g$common,e$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,c$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,a$common)
union2 <- as.data.frame(union2)

union1 <- union(union1$union1,union2$union2)
union1 <- as.data.frame(union1)



write.csv(union1,file = "appear3_283time.csv")

#Appear 2 times 3_28
union1 <- union(b$common,d$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(b$common,d$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,f$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,f$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,h$common)
union2 <- as.data.frame(union2)

union1 <- union(f$common,d$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(f$common,d$common)), ]
union1 <- as.data.frame(union1)
union3 <- union(union3$union3,h$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union1$union1,h$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,b$common)
union3 <- as.data.frame(union3)

union2 <- union(union2$union2,union3$union3)
union2 <- as.data.frame(union2)


write.csv(union2,file = "appear3_282time.csv")

#Appear 2 times LCL
union1 <- union(a$common,c$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(a$common,c$common)), ]
union1 <- as.data.frame(union1)
union2 <- union(union1$union1,e$common)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(union1$union1,e$common)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,g$common)
union2 <- as.data.frame(union2)

union1 <- union(c$common,e$common)
union1 <- as.data.frame(union1)
union1 <- union1[!(union1$union1 %in% intersect(c$common,e$common)), ]
union1 <- as.data.frame(union1)
union3 <- union(union3$union3,g$common)
union3 <- as.data.frame(union3)
union3 <- union3[!(union3$union3 %in% intersect(union1$union1,g$common)), ]
union3 <- as.data.frame(union3)
union3 <- intersect(union3$union3,a$common)
union3 <- as.data.frame(union3)

union2 <- union(union2$union2,union3$union3)
union2 <- as.data.frame(union2)


write.csv(union2,file = "appear3_282time.csv")






























#Other possibilities
union2 <- union(b$common,d$common1)
union2 <- as.data.frame(union2)
union2 <- union2[!(union2$union2 %in% intersect(b$common,d$common1)), ]
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,c$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,c$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,d$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,e$common)
union2 <- as.data.frame(union2)






union2 <- union(a$common,c$common1)
union2 <- as.data.frame(union2)
union2 <- intersect(union2$union2,b$common)
union2 <- as.data.frame(union2)
union2 <- intersect(union1$union1,d$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,e$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,f$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,g$common)
union1 <- as.data.frame(union1)
union1 <- intersect(union1$union1,h$common)
union1 <- as.data.frame(union1)




hvgcommon1<-intersect(b$common,d$common)
hvgcommon2<-intersect(f$common,h$common)
hvgcommon1<-as.data.frame(hvgcommon1)
hvgcommon2<-as.data.frame(hvgcommon2)


hvgcommon<- intersect(hvgcommon1$hvgcommon1,hvgcommon2$hvgcommon2)
hvgcommon<-as.data.frame(hvgcommon)

write.csv(hvgcommon,file = "combinedLCLintersection.csv")

write.csv(intersection,file="intersection.csv")
write.csv(intersection,file="3-28intersection.csv")
write.csv(intersection,file="LCLintersection.csv")



write.csv(hvgcommon6,file = "combined8pintersection.csv")
write.csv(hvgcommon1,file = "combinedDMintersection.csv")
write.csv(hvgcommon2,file = "combinedRHintersection.csv")
write.csv(hvgcommon3,file = "combinedWYOintersection.csv")
write.csv(hvgcommon4,file = "combinedZHBintersection.csv")