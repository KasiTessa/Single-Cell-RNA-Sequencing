#Read 10x data
Three <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_3GEX/DM_3_28_hg19/")
Five <- Read10X(data.dir = "C:/Users/kasigopikanna/Desktop/20181008_3GEX/Enjun/20181008_5GEX/RH_LCL_hg19/")
#CreateSeuratObject
Thr <- CreateSeuratObject(counts = Three, min.cells = 3, min.features = 200,project = "10X_3GEX")
Fiv <- CreateSeuratObject(counts = Five, min.cells = 3, min.features = 200,project = "10X_5GEX")
#Fiv1 <- CreateSeuratObject(raw.data = Five, min.cells = 3, do.logNormalise = TRUE, total.expr = 1e4, min.genes = 200, project = "10X_5GEX")
# Get summary of data
#str(Five)
#Dimension reduction using PCA
#Dimensions of raw.data
dim(Thr@raw.data)
dim(Fiv@raw.data)


#See size of objects
dense.size <- object.size(x = as.matrix(x = Five))
sparse.size <- object.size(x = Five)

#try to identify high mitochondrial genes
mito.genes <- grep(pattern = "^MT-", x = rownames(x = Thr@data), value = TRUE)
percent.mito <- Matrix::colSums(Thr@raw.data[mito.genes, ])
#mito.genes1 <- grep(pattern = "^MT-", x = rownames(x = Fiv@data), value = TRUE)
#percent.mito1 <- Matrix::colSums(Fiv@raw.data[mito.genes1, ])

# Add the mitochondrial genes and plot the plot to see if there are many outliers
Thr <- AddMetaData(object = Thr, metadata = percent.mito, col.name = "percent.mito")
#VlnPlot(object = Thr, features.plot = c("nGene", "nUMI","percent.mito"), nCol = 3)

#Fiv <- AddMetaData(object = Fiv, metadata = percent.mito1, col.name = "percent.mito")
#VlnPlot(object = Fiv, features.plot = c("nGene", "nUMI","percent.mito1"), nCol = 3)

#See the R value of the mitochondrial value and compare with normal genes and if it is high remove them
#par(mfrow = c(1, 2))
#GenePlot(object = Thr, gene1 = "nUMI", gene2 = "percent.mito1")
#GenePlot(object = Thr, gene1 = "nUMI", gene2 = "nGene")

#par(mfrow = c(1, 2))
#GenePlot(object = Fiv, gene1 = "nUMI", gene2 = "percent.mito1")
#GenePlot(object = Fiv, gene1 = "nUMI", gene2 = "nGene")

# We filter out cells that have unique gene counts over 2,500 or less than
# 200 Note that low.thresholds and high.thresholds are used to define a
# 'gate'. 
Thr <- FilterCells(object = Thr, subset.names = c("nGene"), 
                   low.thresholds = c(200, -Inf), high.thresholds = c(2500, 0.05))
#Fiv2 <- FilterCells(object = Fiv2, subset.names = c("nGene"), 
            #low.thresholds = c(200, -Inf), high.thresholds = c(2500, 0.05))

#Normalise data. 
Thr <- NormalizeData(object = Thr, normalization.method = "LogNormalize", 
                     scale.factor = 10000)
#Fiv <- NormalizeData(object = Fiv, normalization.method = "LogNormalize", 
                    #  scale.factor = 10000)
#Find variable genes across single cells
#Fiv <-FindVariableGenes(object = Fiv, do.plot = FALSE)
Thr <-FindVariableGenes(object = Thr, do.plot = FALSE)
#Scaling data and regressing out the unique molecule identifiers
#Fiv <- ScaleData(object = Fiv, vars.to.regress = c("nUMI"))
Thr <- ScaleData(object = Thr, vars.to.regress = c("nUMI"))

#Perform linear dimensional reduction since running dimensionality reduction on highly variable genes can improve performance
Fiv <- RunPCA(object = Fiv, pc.genes = Fiv@var.genes, do.print = TRUE, pcs.print = 1:5, 
              genes.print = 5)
Thr <- RunPCA(object = Thr, pc.genes = Thr@var.genes, do.print = TRUE, pcs.print = 1:5, 
              genes.print = 5)

#Fiv <- RunPCA(object = Fiv, pc.genes = intersection$intersection, do.print = TRUE, pcs.print = 1:5, 
              #genes.print = 5)
#Thr <- RunPCA(object = Thr, pc.genes = intersection$intersection, do.print = TRUE, pcs.print = 1:5, 
              #genes.print = 5)

#Print length of variable genes and Store variable genes
length(x=Thr@var.genes)
length(x=Fiv@var.genes)
a <- Thr@var.genes
b <- Fiv@var.genes
a <- as.data.table(a)
b <- as.data.table(b)
colnames(a) <- c("Variable genes")
colnames(b) <- c("Variable genes")
common <- intersect(a$`Variable genes`, b$`Variable genes`)
common <- as.data.table(common)
comgenes <- setdiff(a$`Variable genes`,b$`Variable genes`)
comgenes <- as.data.table(comgenes)
comgenes1 <- setdiff(b$`Variable genes`,a$`Variable genes`)
comgenes1 <- as.data.table(comgenes1)

# Find the intersection of those with having info once done normalising and scaling and removing highly occurring mitochondrial genes
#First 2000 genes having info. hvg.Fiv <- rownames(x = head(x=Fiv@hvg.info, n = 2000))
a2 <- rownames(x=Thr@hvg.info)
a1 <- rownames(haveinfo)
b2 <- rownames(x=Fiv@hvg.info)
a2 <- data.frame(a2)
b2 <- data.frame(b2)

hvg.Thr <- merge(Thr@hvg.info,a2,by="row.names",all.x=TRUE)
hvg.Fiv <- merge(Fiv@hvg.info,b2,by="row.names",all.x=TRUE)
hvgcommon <- intersect(hvg.Fiv$Row.names, hvg.Thr$Row.names)
hvg.Thr <- as.data.table(hvg.Thr)
hvg.Fiv <- as.data.table(hvg.Fiv)
hvg.Thr$a2 <- NULL
hvg.Fiv$b2 <- NULL
hvgcommon <- as.data.table(hvgcommon)
hvgcommon1 <- setdiff(hvg.Thr2$Row.names,hvg.Fiv2$Row.names)
hvgcommon1 <- as.data.table(hvgcommon1)
hvgcommon2 <- setdiff(hvg.Fiv2$Row.names,hvg.Thr2$Row.names)
hvgcommon2 <- as.data.table(hvgcommon2)
#Take the first common intersection value and compare info
#hvg.Thr2[grep("7SK.1",hvg.Thr$Row.names)]
#hvg.Fiv2[grep("7SK.1",hvg.Fiv$Row.names)]
#subset and group by gene
set<- subset(hvg.Thr, Row.names %in% hvgcommon$hvgcommon)
set1<- subset(hvg.Fiv, Row.names %in% hvgcommon$hvgcommon)
combined <- rbind(set,set1)
combined <- combined[order(Row.names)]
combinedmean <- combined %>% group_by(Row.names) %>% summarise_all(funs(mean))
combineddiff <- combined %>% group_by(Row.names) %>% summarise_all(funs(diff))
# can see individual groups grouped <- split(combined,combined$Row.names,drop = FALSE)

#Write to csv files
write.csv(combineddiff,file = "combineddiff8.csv")
write.csv(combinedmean,file = "combinedmean8.csv")
write.csv(combined,file = "combined8.csv")
write.csv(common,file = "commongenes8.csv")
write.csv(comgenes,file = "leftsidegenes8.csv")
write.csv(comgenes1,file = "rightsidegenes8.csv")
write.csv(hvgcommon,file = "intersection8.csv")
write.csv(hvgcommon1,file = "leftsidejoin8.csv")
write.csv(hvgcommon2,file = "rightsidejoin8.csv")














#Find variable genes across single cells. Calculates the average expression and dispersion for each gene, places these genes into bins, and then calculates a z-score for dispersion within each bin. This helps control for the relationship between variability and average expression. Prints out the dispersion and average expression of each variable gene 
Fiv <- FindVariableGenes(object = Fiv, mean.function = ExpMean, dispersion.function = LogVMR, 
                         x.low.cutoff = 0.0125, x.high.cutoff = 3, y.cutoff = 0.5)
Thr <- FindVariableGenes(object = Thr, mean.function = ExpMean, dispersion.function = LogVMR, 
                         x.low.cutoff = 0.0125, x.high.cutoff = 3, y.cutoff = 0.5)








#join the genes having info from both types of files
hvg.union <- union (x = hvg.Thr , y = hvg.Fiv)

#Add 3Gex/5Gex to protocol in meta data 
Fiv@meta.data[,"protocol"] <-  "5GEX"

#
dat_1 <- RunCCA(object = Thr, object2 = Fiv, genes.use = hvg.union)






#Find variable genes across single cells. Calculates the average expression and dispersion for each gene, places these genes into bins, and then calculates a z-score for dispersion within each bin. This helps control for the relationship between variability and average expression. 
Fiv <- FindVariableGenes(object = Fiv, mean.function = ExpMean, dispersion.function = LogVMR, 
                          x.low.cutoff = 0.0125, x.high.cutoff = 3, y.cutoff = 0.5)

#Scaling the data and removing unwanted sources of variation
Fiv <- ScaleData(object = Fiv, vars.to.regress = c("nUMI", "percent.mito"))

#Perform linear dimensional reduction. Next we perform PCA on the scaled data. By default, the genes in object@var.genes are used as input, but can be defined using pc.genes. We have typically found that running dimensionality reduction on highly variable genes can improve performance. 
Fiv <- RunPCA(object = Fiv, pc.genes = Fiv@var.genes, do.print = TRUE, pcs.print = 1:5, 
               genes.print = 5)

#Visualise PC plots
#VizPCA(object = Fiv, pcs.use = 1:2)

#Compare pca plots
#PCAPlot(object = Fiv, dim.1 = 1, dim.2 = 2) 

#Do PC heatmap
#PCHeatmap(object = Fiv, pc.use = 1, cells.use = 500, do.balanced = TRUE, label.columns = FALSE)

#Determine statistically significant principal components 
#Fiv <- JackStraw(object = Fiv, num.replicate = 100, display.progress = FALSE)
#JackStrawPlot(object = Fiv, PCs = 1:12)

#PCElbowPlot
#PCElbowPlot(object = Fiv)

#Find PCA Clusters and print the parameters chosen
Fiv <- FindClusters(object = Fiv, reduction.type = "pca", dims.use = 1:10, resolution = 0.6, print.output = 0, save.SNN = TRUE)clusters
PrintFindClustersParams(object = Fiv)

#Run non-linear dimensional reduction
Fiv <- RunTSNE(object = Fiv, dims.use = 1:10, do.fast = TRUE)
TSNEPlot(object = Fiv, do.label = T)

#saveRDS file from TSNE
saveRDS(Fiv, file = "C:/Users/kasigopikanna/Desktop/Fiv.rds")

# find all markers of cluster 1, differentially expressed genes
cluster1.markers <- FindMarkers(object = Fiv, ident.1 = 1, min.pct = 0.25)
print(x = head(x = cluster1.markers, n = 5))

# find markers for every cluster compared to all remaining cells, report
# only the positive ones
Fiv.markers <- FindAllMarkers(object = Fiv, only.pos = TRUE, min.pct = 0.25, 
                               thresh.use = 0.25)
Fiv.markers %>% group_by(cluster) %>% top_n(2, avg_logFC)

#expression probability distribution across clusters
VlnPlot(object = Fiv, features.plot = c("CD79A"))

# you can plot raw UMI counts as well
VlnPlot(object = Fiv, features.plot = c("NKG7"), use.raw = TRUE, y.log = TRUE)

#Plot Feature plot
FeaturePlot(object = Fiv, features.plot = c("GNLY", "CD3E", "CD14", 
                                             "FCGR3A", "CD8A"), cols.use = c("grey", "blue"), 
            reduction.use = "tsne")
#generates an expression heatmap for given cells and genes. In this case, we are plotting the top 10 markers (or all markers if less than 10) for each cluster.
top10 <- Fiv.markers %>% group_by(cluster) %>% top_n(10, avg_logFC)
# setting slim.col.label to TRUE will print just the cluster IDS instead of
# every cell name
DoHeatmap(object = Fiv, genes.use = top10$gene, slim.col.label = TRUE, remove.key = TRUE)
DoHeatmap(object = Thr, genes.use = top10$gene, slim.col.label = TRUE, remove.key = TRUE)
#DoHeatmap(object = Thr, genes.use = intersection$intersection, slim.col.label = TRUE, remove.key = TRUE)

#Assigning cell type to clusters
#current.cluster.ids <- c(0, 1, 2, 3, 4, 5, 6, 7)
#new.cluster.ids <- c("CD4 T cells", "CD14+ Monocytes", "B cells", "CD8 T cells", 
    #                 "FCGR3A+ Monocytes", "NK cells", "Dendritic cells", "Megakaryocytes")
#Fiv@ident <- plyr::mapvalues(x = Fiv@ident, from = current.cluster.ids, to = new.cluster.ids)
#TSNEPlot(object = Fiv, do.label = TRUE, pt.size = 0.5)

library(datatable)
data_to_write_out <- as.data.frame(as.matrix(All_Combined@scale.data))

